class RekuestError(Exception):
    """Base class for all Rekuest exceptions."""

    pass

