from typing import Protocol
